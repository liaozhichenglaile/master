<?php
/*
 * @Author: dashing
 * @Date: 2021/1/21 18:20
 */

namespace app\common\model;


class Dictionary extends BaseModel
{

}
