<?php
/*
 * @Author: dashing
 * @Date: 2021/1/18 16:06
 */

namespace app\admin\controller\user;


use app\common\validate\UserValidate;
use app\services\user\UserServices;
use think\App;

class UserController extends \app\admin\controller\BaseController
{
	/**
	 * @var UserServices
	 */
	protected $services;

	public function __construct(App $app, UserServices $services)
	{
		parent::__construct($app);
		$this->services = $services;
	}

	public function getList()
	{
		$data = $this->request->getMore([
			['name'],
			['add_time'],
			['tel'],
			['identity'],
			['page', 0],
			['limit', 0]
		]);

		return $this->successful($this->services->getList($data));
	}
}
