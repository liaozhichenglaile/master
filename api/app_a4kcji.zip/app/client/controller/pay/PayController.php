<?php
/*
 * @Author: dashing
 * @Date: 2021/1/21 11:23
 */

namespace app\client\controller\pay;


use app\common\validate\UserValidate;
use app\facade\WxServices;
use app\services\user\UserServices;
use thans\jwt\facade\JWTAuth;
use think\App;
use think\facade\Db;
use think\exception\ValidateException;
use think\facade\Cache;

class PayController extends \app\client\controller\BaseController
{
	protected $services;

	public function __construct(App $app, UserServices $services)
	{
	 
		parent::__construct($app);
		$this->services = $services;
	}

	
	
	
	//小程序支付
	public function pay(){
	  include 'wxpay.php';

	 $res1=db::name('order')->where(['uid'=>$this->user->id,'status'=>1,'remark'=>'充值艺人'])->field('id')->find();
  	    
	  //新老玩家判断
	  if(!$res1){
	      
	   $userinfo=Db::name('artist')->where('uid',$this->user->id)->field('id')->find();
	  
	  $res=db::name('order')->where(['uid'=>$this->user->id,'status'=>2,'remark'=>'充值艺人'])->field('id')->find(); 
	 
	  if(!$userinfo || $res){

	  $openid=$this->user->openid;
	  $out_trade_no=date('YmdHis').rand(100000,999999);
	  $total_fee=10000;
	  $body = '订单付款';
	  
	  $weixinpay = new \WxPay( $openid,$out_trade_no, $body, $total_fee);

      $return = $weixinpay->pay();
      $return['code']=1000;
      //创建订单
  
      Db::name('order')->insert([
          'uid'        => $this->user->id,
          'orderid'    => $out_trade_no,
          'openid'     => $openid,
          'createtime' => time(),
          'remark'     => '充值艺人',
          'money'      => $total_fee/100
          ]);
          
        return $this->successful($return);
  	  }
  	  }
  	  
  	      
  	    
  	    $return=['code'=>1001];
  	    $this->successful($return);   
  	  
	  
	   return $this->successful($return);
	  

	}
	
	
		//小程序支付
	public function notify(){
	    $testxml  = file_get_contents("php://input");
       
        $jsonxml = json_encode(simplexml_load_string($testxml, 'SimpleXMLElement', LIBXML_NOCDATA));
       
        $result = json_decode($jsonxml, true);//转成数组，
        
        if($result){
            //如果成功返回了
            $out_trade_no = $result['out_trade_no'];
                if($result['return_code'] == 'SUCCESS' && $result['result_code'] == 'SUCCESS'){
                //执行业务逻辑
                $res=db::name('order')->where(['orderid'=>$out_trade_no,'status'=>0])->field('id')->find();
                if($res){
                   Db::name('order')->where('orderid',$out_trade_no)->update([
                    'status'=>1,
                    'transaction_id'=>$result['transaction_id'],
                    'paytime'=>time()
                    ]);
                }  
                }
               
        }
        return '{"code": "SUCCESS","message": ""}';

	}


}
