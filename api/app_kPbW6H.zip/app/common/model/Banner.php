<?php
/*
 * @Author: dashing
 * @Date: 2021/1/21 18:00
 */

namespace app\common\model;


class Banner extends BaseModel
{

}
