<?php
/*
 * @Author: dashing
 * @Date: 2021/1/29 15:42
 */

namespace app\common\model;


class Collect extends BaseModel
{

}
